// RTB Pulse — Background Service Worker

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// Listen for messages from the side panel
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'FETCH_RTB') {
    handleRTBFetch(msg).then(sendResponse).catch(err => sendResponse({ error: err.message }));
    return true; // keep channel open for async
  }
  if (msg.type === 'OPEN_TABS') {
    handleOpenTabs(msg).then(sendResponse).catch(err => sendResponse({ error: err.message }));
    return true;
  }
});

// ── Fetch all 4 RTB URLs (no tabs, pure fetch) ────────────────────────────────
async function handleRTBFetch({ callerId, zipCode }) {
  const urls = buildUrls(callerId, zipCode);
  const results = await Promise.all(
    urls.map(async ({ label, url }) => {
      try {
        const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
        const json = await res.json();
        return { label, url, success: true, data: json };
      } catch (e) {
        return { label, url, success: false, error: e.message };
      }
    })
  );
  return { results };
}

// ── Open tabs, fetch responses, optionally close ──────────────────────────────
async function handleOpenTabs({ callerId, zipCode, closeAfter }) {
  const urls = buildUrls(callerId, zipCode);
  const results = [];

  for (const { label, url } of urls) {
    try {
      // Create the tab
      const tab = await chrome.tabs.create({ url, active: false });

      // Wait for the tab to finish loading
      const json = await waitForTabResponse(tab.id, url);

      if (closeAfter) {
        chrome.tabs.remove(tab.id).catch(() => {});
      }

      results.push({ label, url, success: true, data: json });
    } catch (e) {
      results.push({ label, url, success: false, error: e.message });
    }
  }

  return { results };
}

// Wait for a tab to load and capture its JSON body
function waitForTabResponse(tabId, url) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      cleanup();
      reject(new Error('Tab timed out after 20s'));
    }, 20000);

    function onUpdated(id, changeInfo) {
      if (id !== tabId || changeInfo.status !== 'complete') return;
      cleanup();
      // Execute script to grab the page body text
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => document.body.innerText
      }).then(results => {
        try {
          const text = results[0]?.result || '{}';
          resolve(JSON.parse(text));
        } catch {
          reject(new Error('Failed to parse response JSON'));
        }
      }).catch(reject);
    }

    function cleanup() {
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(onUpdated);
    }

    chrome.tabs.onUpdated.addListener(onUpdated);
  });
}

// ── Build the 4 RTB URLs ──────────────────────────────────────────────────────
function buildUrls(callerId, zipCode) {
  const p = `CALLER_ID=${encodeURIComponent(callerId)}&ZIP_CODE=${encodeURIComponent(zipCode)}`;
  return [
    {
      label: 'Siding',
      url: `https://rtb.moja.cloud/inbound_rtb/rtb_6b2efee00a1b47c5891c1f1b5294699a?${p}`
    },
    {
      label: 'Bath',
      url: `https://rtb.moja.cloud/inbound_rtb/inbound_rtb_1774894662511_ea2800ce?${p}`
    },
    {
      label: 'Roofing',
      url: `https://rtb.moja.cloud/inbound_rtb/rtb_f492cc4906594d908ebf53a24c0db9ad?${p}`
    },
    {
      label: 'Windows',
      url: `https://rtb.moja.cloud/inbound_rtb/rtb_b7820dee89bb402fbea459d2db4c41b1?${p}`
    }
  ];
}
