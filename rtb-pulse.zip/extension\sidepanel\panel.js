// RTB Pulse - Side Panel Logic

const LABELS = ['Siding', 'Bath', 'Roofing', 'Windows'];
const LABEL_ICONS = { Siding: '🏠', Bath: '🛁', Roofing: '🔨', Windows: '🪟' };

const API_BASE = 'https://rtb-pulse.vercel.app';

let currentMode = 'none';
let deviceId = '';
let userStatus = null;

let profilesData = {
  1: { callerId: '', zipCode: '', results: [], status: 'idle', elapsed: '0.0', summary: null },
  2: { callerId: '', zipCode: '', results: [], status: 'idle', elapsed: '0.0', summary: null }
};

// Init
document.addEventListener('DOMContentLoaded', async () => {
  deviceId = await getDeviceId();
  document.getElementById('deviceIdLicense').textContent = deviceId;

  // Retrieve and set tab mode
  const stored = await chrome.storage.local.get(['tabMode']);
  if (stored.tabMode) setMode(stored.tabMode, document.querySelector(`[data-mode="${stored.tabMode}"]`));

  // Initialize Theme
  const themeData = await chrome.storage.local.get(['theme']);
  const currentTheme = themeData.theme || 'dark';
  applyTheme(currentTheme);

  // Theme toggle click handler
  document.getElementById('themeToggleBtn').addEventListener('click', () => {
    const isLight = document.body.classList.contains('light-theme');
    const newTheme = isLight ? 'dark' : 'light';
    applyTheme(newTheme);
  });

  await refreshStatus();

  // Restore profiles from storage
  try {
    const storedProfiles = await chrome.storage.local.get(['profilesData']);
    if (storedProfiles.profilesData) {
      // Clean 4 profile fallback to 2 profiles
      const loaded = storedProfiles.profilesData;
      profilesData[1] = loaded[1] || profilesData[1];
      profilesData[2] = loaded[2] || profilesData[2];

      for (let i = 1; i <= 2; i++) {
        const p = profilesData[i];
        if (p) {
          document.getElementById(`callerId-${i}`).value = p.callerId || '';
          document.getElementById(`zipCode-${i}`).value = p.zipCode || '';
          updateProfileStatusUI(i, p.status);
          if (p.summary) {
            displaySummaryUI(i, p.summary);
          }
          if (p.results && p.results.length > 0) {
            renderProfileResults(i, p.results);
          }
        }
      }
    }
  } catch (err) {
    console.error('Error restoring profiles:', err);
  }

  // Set up listeners for the 2 profiles
  for (let i = 1; i <= 2; i++) {
    const pId = i;
    
    // Fire button
    document.getElementById(`fireBtn-${pId}`).addEventListener('click', () => firePings(pId));
    
    // Clear button
    document.getElementById(`clearBtn-${pId}`).addEventListener('click', () => clearProfile(pId));
    
    // Inputs (to save on the fly)
    const phoneInput = document.getElementById(`callerId-${pId}`);
    const zipInput = document.getElementById(`zipCode-${pId}`);
    
    phoneInput.addEventListener('input', () => {
      phoneInput.value = cleanInputPhoneNumber(phoneInput.value);
      saveProfileStateToStorage(pId);
    });
    zipInput.addEventListener('input', () => saveProfileStateToStorage(pId));
  }

  // Paste buttons handler
  document.querySelectorAll('.paste-btn').forEach(btn => {
    btn.addEventListener('click', () => handlePaste(btn.dataset.target));
  });

  // Nav Switching (Only Fire and License remain)
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => switchPanel(btn.dataset.panel, btn));
  });

  // Tab Mode Switching
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => setMode(btn.dataset.mode, btn));
  });

  // Global listeners
  document.getElementById('activateBtn').addEventListener('click', activateLicense);
  document.getElementById('copyDeviceIdBtnLic').addEventListener('click', () => {
    copyText(deviceId);
    showToast('📋 Device ID copied');
  });
  document.getElementById('clearCacheBtn').addEventListener('click', clearBrowserCache);
});

// Strip +1 or 1 prefix, and keep exactly 10 digits
function cleanInputPhoneNumber(val) {
  let digits = val.replace(/[^\d]/g, '');
  if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.slice(1);
  }
  if (digits.length > 10) {
    digits = digits.substring(0, 10);
  }
  return digits;
}

// Paste handler
async function handlePaste(targetId) {
  try {
    const text = await navigator.clipboard.readText();
    const input = document.getElementById(targetId);
    if (input) {
      if (targetId.startsWith('callerId-')) {
        input.value = cleanInputPhoneNumber(text);
      } else {
        input.value = text.trim();
      }
      const pId = targetId.split('-')[1];
      saveProfileStateToStorage(pId);
      showToast('📋 Pasted');
    }
  } catch (err) {
    showToast('❌ Clipboard permission denied');
  }
}

// Save profile state
function saveProfileStateToStorage(profileId) {
  profilesData[profileId].callerId = document.getElementById(`callerId-${profileId}`).value.trim();
  profilesData[profileId].zipCode = document.getElementById(`zipCode-${profileId}`).value.trim();
  chrome.storage.local.set({ profilesData });
}

// Clear profile inputs & results
function clearProfile(profileId) {
  document.getElementById(`callerId-${profileId}`).value = '';
  document.getElementById(`zipCode-${profileId}`).value = '';
  document.getElementById(`results-${profileId}`).innerHTML = '';
  
  const bar = document.getElementById(`summaryBar-${profileId}`);
  if (bar) bar.style.display = 'none';

  updateProfileStatusUI(profileId, 'idle');
  
  profilesData[profileId] = { callerId: '', zipCode: '', results: [], status: 'idle', elapsed: '0.0', summary: null };
  chrome.storage.local.set({ profilesData });
  showToast(`🗑️ Profile ${profileId} cleared`);
}

// Update profile status
function updateProfileStatusUI(profileId, status) {
  const dot = document.getElementById(`status-dot-${profileId}`);
  if (dot) {
    dot.className = `profile-dot status-${status}`;
  }
  profilesData[profileId].status = status;
  chrome.storage.local.set({ profilesData });
}

// Render Results per profile
function renderProfileResults(profileId, results) {
  const container = document.getElementById(`results-${profileId}`);
  if (!container) return;

  // Sort results: positive leads first, then no match or failed ones
  const sortedResults = [...results].sort((a, b) => {
    const aHas = a.success && a.data?.eligible_routes?.length > 0;
    const bHas = b.success && b.data?.eligible_routes?.length > 0;
    if (aHas && !bHas) return -1;
    if (!aHas && bHas) return 1;
    return 0;
  });

  container.innerHTML = sortedResults.map(r => renderDetailedCard(profileId, r)).join('');
  
  // Wire buttons for this profile
  wireProfileCardButtons(container);
}

// Render a single detailed card
function renderDetailedCard(profileId, r) {
  const icon = LABEL_ICONS[r.label] || '🌐';
  const routes = r.data?.eligible_routes || [];
  const hasRoutes = routes.length > 0;
  const dotClass  = !r.success ? 'red' : hasRoutes ? 'green' : 'gray';
  const cardClass = !r.success ? 'errored' : hasRoutes ? 'has-routes' : 'no-routes';
  const reqId = r.data?.request_id ? r.data.request_id.substring(0, 8) + '...' : '';
  const allocTime = r.data?.allocation_time_seconds !== undefined ? r.data.allocation_time_seconds : 60;
  const ts = r.data?.timestamp ? new Date(r.data.timestamp).toLocaleTimeString() : '';

  const routesHtml = routes.length > 0
    ? routes.map(route => {
        const rawNum = route.number || '';
        // Strip leading +1 or 1 if it is present
        const routeNum = rawNum.startsWith('+1') ? rawNum.slice(2) : (rawNum.startsWith('1') && rawNum.length === 11 ? rawNum.slice(1) : rawNum);
        const payoutVal = route.payout ? '$' + route.payout.toFixed(2) : '$0.00';
        
        return `
          <div class="route-row" style="display: flex; flex-direction: column; gap: 6px; padding: 8px; background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius-sm); margin-bottom: 6px;">
            <!-- Row 1: Route Number Label & Number + Copy -->
            <div style="display: flex; flex-direction: column; gap: 2px; width: 100%;">
              <span class="route-box-label">Route Number</span>
              <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px;">
                <span class="route-number positive" style="font-size: 15px;">${routeNum}</span>
                <button class="copy-num-btn" data-copy="${routeNum}" title="Copy Number" style="padding: 2px 5px; font-size: 9px; flex-shrink: 0;">
                  📋 Copy
                </button>
              </div>
            </div>
            
            <!-- Divider -->
            <div style="height: 1px; background: var(--border); width: 100%; margin: 2px 0;"></div>
            
            <!-- Row 2: Allocation Badge & Payout Badge + Copy -->
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 4px; width: 100%;">
              <!-- Allocation -->
              <div style="display: flex; flex-direction: column; gap: 2px; min-width: 0;">
                <span class="route-box-label" style="font-size: 7px;">Allocation</span>
                <span class="route-alloc-badge" style="font-size: 10px; padding: 2px 4px;">⏳ ${allocTime}s</span>
              </div>
              
              <!-- Payout -->
              <div style="display: flex; flex-direction: column; gap: 2px; align-items: flex-end; min-width: 0;">
                <span class="route-box-label" style="font-size: 7px;">Bid Payout</span>
                <div style="display: flex; align-items: center; gap: 2px;">
                  <span class="route-payout" style="font-size: 11px; padding: 2px 4px;">${payoutVal}</span>
                  <button class="copy-bid-btn" data-copy="${payoutVal}" title="Copy Bid" style="padding: 2px 4px; font-size: 8px; flex-shrink: 0;">
                    📋 Copy
                  </button>
                </div>
              </div>
            </div>
          </div>`;
      }).join('')
    : `<div class="no-routes-msg">No eligible routes</div>`;

  const errorHtml = !r.success
    ? `<div style="font-size:12px;color:var(--danger); font-weight:500;">⚠️ ${r.error || 'Request failed'}</div>`
    : '';

  const pills = [];
  if (r.data?.total_routes !== undefined) pills.push(`${r.data.total_routes} route${r.data.total_routes !== 1 ? 's' : ''}`);
  if (r.data?.allocation_time_seconds) pills.push(`${r.data.allocation_time_seconds}s window`);
  if (reqId) pills.push(`ID: ${reqId}`);
  if (ts) pills.push(ts);

  // Copy both: join numbers and bids (cleaned of +1)
  const copyBothVal = routes.map(rt => {
    const rawNum = rt.number || '';
    const cleanNum = rawNum.startsWith('+1') ? rawNum.slice(2) : (rawNum.startsWith('1') && rawNum.length === 11 ? rawNum.slice(1) : rawNum);
    return `${cleanNum} - $${(rt.payout || 0).toFixed(2)}`;
  }).join('\n');

  const copyBothBtnHtml = hasRoutes
    ? `<button class="copy-both-btn" data-copy="${copyBothVal}" title="Copy Number & Bid">📋 Copy Both</button>`
    : '';

  return `
    <div class="result-card ${cardClass}">
      <div class="card-header">
        <div class="card-dot ${dotClass}"></div>
        <span class="card-label">${icon} ${r.label}</span>
        <span class="card-meta">${hasRoutes ? routes.length + ' route' + (routes.length > 1 ? 's' : '') : 'No match'}</span>
        ${copyBothBtnHtml}
        <button class="card-url-btn" data-copy="${encodeURIComponent(r.url)}" title="Copy URL">🔗</button>
      </div>
      <div class="card-body">
        ${errorHtml}
        ${r.success ? routesHtml : ''}
      </div>
      ${pills.length ? `<div class="card-footer">${pills.map(p => `<span class="meta-pill">${p}</span>`).join('')}</div>` : ''}
    </div>`;
}

// Wire detailed copy buttons
function wireProfileCardButtons(container) {
  container.querySelectorAll('.copy-num-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      copyText(btn.dataset.copy);
      showToast('📋 Number copied');
    });
  });

  container.querySelectorAll('.copy-bid-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      copyText(btn.dataset.copy);
      showToast('📋 Payout bid copied');
    });
  });

  container.querySelectorAll('.copy-both-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      copyText(btn.dataset.copy);
      showToast('📋 Copied Number & Bid');
    });
  });

  container.querySelectorAll('.card-url-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      copyText(btn.dataset.copy);
      showToast('🔗 URL copied');
    });
  });
}

// Render summary
function renderSummary(profileId, results, elapsed) {
  const totalRoutes = results.reduce((s, r) => s + (r.data?.eligible_routes?.length || 0), 0);
  const maxPayout   = results.reduce((max, r) => {
    const routes = r.data?.eligible_routes || [];
    const top = routes.reduce((m, rt) => Math.max(m, rt.payout || 0), 0);
    return Math.max(max, top);
  }, 0);

  const summary = {
    total: results.length,
    hits: totalRoutes,
    payout: maxPayout > 0 ? `$${maxPayout.toFixed(2)}` : '$0',
    time: elapsed + 's'
  };

  profilesData[profileId].summary = summary;
  chrome.storage.local.set({ profilesData });

  displaySummaryUI(profileId, summary);
}

function displaySummaryUI(profileId, summary) {
  const bar = document.getElementById(`summaryBar-${profileId}`);
  if (!bar) return;

  document.getElementById(`sumTotal-${profileId}`).textContent  = summary.total;
  document.getElementById(`sumHits-${profileId}`).textContent   = summary.hits;
  document.getElementById(`sumPayout-${profileId}`).textContent = summary.payout;
  document.getElementById(`sumTime-${profileId}`).textContent   = summary.time;
  bar.style.display = 'grid';
}

// Skeleton profile item loading view
function skeletonCard(label) {
  const icon = LABEL_ICONS[label] || '🌐';
  return `
    <div class="result-card loading">
      <div class="card-header">
        <div class="card-dot spin"></div>
        <span class="card-label">${icon} ${label}</span>
        <span class="card-meta">Fetching...</span>
      </div>
      <div class="card-body">
        <div class="skeleton" style="width:85%"></div>
        <div class="skeleton" style="width:60%"></div>
      </div>
    </div>`;
}

// Theme helper
function applyTheme(theme) {
  const body = document.body;
  const themeIcon = document.getElementById('themeIcon');
  if (theme === 'light') {
    body.classList.add('light-theme');
    themeIcon.textContent = '☀️';
  } else {
    body.classList.remove('light-theme');
    themeIcon.textContent = '🌙';
  }
  chrome.storage.local.set({ theme });
}

// Device ID Generator
async function getDeviceId() {
  const { rtbDeviceId } = await chrome.storage.local.get('rtbDeviceId');
  if (rtbDeviceId) return rtbDeviceId;
  const id = 'RTBP-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substring(2, 8).toUpperCase();
  await chrome.storage.local.set({ rtbDeviceId: id });
  return id;
}

// Status Refresh
async function refreshStatus() {
  try {
    const stored = await chrome.storage.local.get(['localUsageCount']);
    const count = stored.localUsageCount || 0;
    userStatus = {
      type: 'premium',
      plan: 'Pro',
      count: count,
      limit: Infinity,
      remaining: Infinity,
      isExpired: false,
      used: count
    };
    renderStatus(userStatus);
  } catch (err) {
    console.error('Error refreshing status:', err);
  }
}

// Render Licensing Status and globally disable/enable buttons
function renderStatus(s) {
  const badge      = document.getElementById('statusBadge');
  const usageCount = document.getElementById('usageCount');
  const usageFill  = document.getElementById('usageFill');
  const usageLabel = document.getElementById('usageLabel');
  const licTitle   = document.getElementById('licStatusTitle');
  const licDesc    = document.getElementById('licStatusDesc');

  if (s.type === 'unlicensed') {
    badge.className = 'status-badge expired';
    badge.textContent = 'Inactive';
    usageLabel.textContent = 'Device Status';
    usageCount.textContent = 'LOCKED';
    usageFill.style.width = '0%';
    usageFill.className = 'usage-fill danger';
    
    licTitle.textContent = 'Unlicensed Device';
    licDesc.innerHTML = 'No active license key found. Please activate a license key to unlock the lead ping engine.';

    for (let i = 1; i <= 2; i++) {
      const btn = document.getElementById(`fireBtn-${i}`);
      if (btn) {
        btn.disabled = true;
        btn.textContent = '⚠️ Activation Required';
      }
    }
    return;
  }

  // Active or expired trial state
  if (s.type === 'trial') {
    badge.className = 'status-badge trial';
    badge.textContent = 'Free';
    usageLabel.textContent = 'Total Usage';
    usageCount.textContent = s.count + ' / ' + s.limit;
    const pct = Math.min(100, (s.count / s.limit) * 100);
    usageFill.style.width = pct + '%';
    usageFill.className = 'usage-fill' + (pct > 80 ? ' danger' : '');
    licTitle.textContent = 'Free Plan Active';
    licDesc.innerHTML = `You have <strong>${s.remaining}</strong> requests remaining. Upgrade for custom access.`;
    
    for (let i = 1; i <= 2; i++) {
      const btn = document.getElementById(`fireBtn-${i}`);
      if (btn) {
        if (s.isExpired) {
          btn.disabled = true;
          btn.textContent = '⚠️ Limit Reached';
        } else if (profilesData[i].status !== 'loading') {
          btn.disabled = false;
          btn.textContent = '🔥 Fire';
        }
      }
    }

    if (s.isExpired) {
      badge.className = 'status-badge expired';
      badge.textContent = 'Expired';
      licTitle.textContent = 'Free Limit Reached';
      licDesc.innerHTML = `You have used all <strong>${s.limit}</strong> free requests. Activate Pro now.`;
    }
  } else {
    badge.className = 'status-badge premium';
    badge.textContent = 'Pro';
    
    usageLabel.textContent = 'Pro Plan 💎 Custom';
    usageCount.textContent = `${s.used || 0} pings fired`;
    usageFill.style.width = '100%';
    usageFill.className = 'usage-fill';
    
    if (s.expiry) {
      const days = Math.max(0, Math.ceil((s.expiry - Date.now()) / 86400000));
      licTitle.textContent = 'Pro License Active';
      licDesc.innerHTML = `<strong>${days}</strong> days remaining with premium priority access.`;
    } else {
      licTitle.textContent = 'Pro License Active';
      licDesc.innerHTML = 'Unlimited custom access activated.';
    }

    for (let i = 1; i <= 2; i++) {
      const btn = document.getElementById(`fireBtn-${i}`);
      if (btn) {
        if (s.isExpired) {
          btn.disabled = true;
          btn.textContent = '⚠️ Expired';
        } else if (profilesData[i].status !== 'loading') {
          btn.disabled = false;
          btn.textContent = '🔥 Fire';
        }
      }
    }
  }
}

// Navigation switcher
function switchPanel(panelId, clickedBtn) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  
  const target = document.getElementById(`panel-${panelId}`);
  if (target) target.classList.add('active');
  if (clickedBtn) clickedBtn.classList.add('active');
}

// Tab Mode configuration
function setMode(mode, clickedBtn) {
  currentMode = mode;
  chrome.storage.local.set({ tabMode: mode });
  document.querySelectorAll('.mode-btn').forEach(btn => btn.classList.remove('active'));
  if (clickedBtn) clickedBtn.classList.add('active');
}

// Firing the independent lead pings
async function firePings(profileId) {
  const callerIdInput = document.getElementById(`callerId-${profileId}`);
  const zipCodeInput = document.getElementById(`zipCode-${profileId}`);
  const callerId = callerIdInput.value.trim();
  const zipCode  = zipCodeInput.value.trim();

  if (!callerId || !zipCode) {
    showToast('⚠️ Enter Caller ID and ZIP');
    return;
  }

  // Save latest inputs
  profilesData[profileId].callerId = callerId;
  profilesData[profileId].zipCode = zipCode;
  await chrome.storage.local.set({ profilesData });

  // Validate request eligibility - bypassed for offline standalone
  const validateRes = { allowed: true };

  const fireBtn = document.getElementById(`fireBtn-${profileId}`);
  fireBtn.disabled = true;
  fireBtn.textContent = '⏳ ...';
  
  updateProfileStatusUI(profileId, 'loading');

  const container = document.getElementById(`results-${profileId}`);
  container.innerHTML = LABELS.map(label => skeletonCard(label)).join('');

  const summaryBar = document.getElementById(`summaryBar-${profileId}`);
  if (summaryBar) summaryBar.style.display = 'none';

  const startTime = Date.now();

  try {
    let results;
    if (currentMode === 'none') {
      const response = await chrome.runtime.sendMessage({ type: 'FETCH_RTB', callerId, zipCode });
      results = response.results;
    } else {
      const closeAfter = currentMode === 'background';
      const response = await chrome.runtime.sendMessage({ type: 'OPEN_TABS', callerId, zipCode, closeAfter });
      results = response.results;
    }

    if (!results) throw new Error('No response from background');

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);

    profilesData[profileId].results = results;
    profilesData[profileId].elapsed = elapsed;
    updateProfileStatusUI(profileId, 'done');

    renderProfileResults(profileId, results);
    renderSummary(profileId, results, elapsed);

    // Record usage
    await recordUsage();
    await refreshStatus();

    showToast(`✨ P${profileId} Done in ${elapsed}s`);

  } catch (err) {
    updateProfileStatusUI(profileId, 'error');
    container.innerHTML = `<div style="color:var(--danger);font-size:10px;padding:4px;text-align:center;">❌ ${err.message}</div>`;
    showToast('❌ ' + err.message);
  } finally {
    // Only re-enable fire button if license is still valid
    if (userStatus && !userStatus.isExpired && userStatus.type !== 'unlicensed') {
      fireBtn.disabled = false;
      fireBtn.textContent = '🔥 Fire';
    }
  }
}

async function recordUsage() {
  try {
    const stored = await chrome.storage.local.get(['localUsageCount']);
    const newCount = (stored.localUsageCount || 0) + 1;
    await chrome.storage.local.set({ localUsageCount: newCount });
  } catch (err) {
    console.error('Error recording usage:', err);
  }
}

async function activateLicense() {
  const key = document.getElementById('activationKey').value.trim().toUpperCase();
  if (!key || !key.startsWith('RTBP-')) {
    showToast('⚠️ Enter a valid RTBP-XXXX-XXXX-XXXX key');
    return;
  }
  const btn = document.getElementById('activateBtn');
  btn.disabled = true;
  btn.textContent = 'Activating...';
  try {
    const res = await fetch(`${API_BASE}/api/activate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: deviceId, key })
    });
    const data = await res.json();
    if (res.ok && data.success) {
      showToast('🎉 Pro License activated!');
      document.getElementById('activationKey').value = '';
      await refreshStatus();
    } else {
      showToast('❌ ' + (data.error || 'Activation failed'));
    }
  } catch {
    showToast('⚠️ Could not reach server');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Activate License';
  }
}

async function clearBrowserCache() {
  const btn = document.getElementById('clearCacheBtn');
  btn.disabled = true;
  btn.textContent = '⏳ Clearing...';
  try {
    await chrome.browsingData.removeCache({ since: 0 });
    showToast('🔄 Cache cleared - requests unblocked');
  } catch {
    const keys = await chrome.storage.local.get(null);
    const cacheKeys = Object.keys(keys).filter(k => k.startsWith('cache_') || k.startsWith('local'));
    if (cacheKeys.length > 0) await chrome.storage.local.remove(cacheKeys);
    showToast('🔄 Local cache cleared');
  } finally {
    btn.disabled = false;
    btn.textContent = '🔄 Clear Browser Cache';
  }
}

// Clipboard copy helper
function copyText(text) {
  const decoded = decodeURIComponent(text);
  navigator.clipboard.writeText(decoded).catch(() => {});
}

// Toast helper
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}


// Intercept manual copy events to strip rich text styling (avoiding color/bg issues when pasting into Excel)
document.addEventListener('copy', (e) => {
  const selection = window.getSelection().toString();
  if (selection) {
    e.clipboardData.setData('text/plain', selection);
    e.preventDefault();
  }
});